<?php
// backend-php/services/ScoreService.php

class ScoreService {
    private $db;
    private $fcm;

    public function __construct($db, $fcm) {
        $this->db = $db;
        $this->fcm = $fcm;
    }

    /**
     * Mock score fetching logic (In production, replace with actual API call)
     */
    public function fetchScore($match_id) {
        // This is a placeholder for your actual API/Firebase fetching logic
        // For demonstration, we'll return a sample state
        return [
            'match_id' => $match_id,
            'runs' => rand(150, 250),
            'wickets' => rand(0, 10),
            'overs' => round(rand(0, 49) + (rand(0, 5) / 6), 1),
            'innings' => 1,
            'batsmen' => [
                ['name' => 'Player A', 'id' => 'p1', 'runs' => rand(40, 110)],
                ['name' => 'Player B', 'id' => 'p2', 'runs' => rand(10, 60)]
            ]
        ];
    }

    public function processMatchUpdate($currentScore) {
        $matchId = $currentScore['match_id'];
        $pdo = $this->db->getConnection();

        // Get last stored state
        $stmt = $pdo->prepare("SELECT * FROM matches WHERE match_id = ?");
        $stmt->execute([$matchId]);
        $lastState = $stmt->fetch();

        if (!$lastState) {
            // New match, initialize it
            $stmt = $pdo->prepare("INSERT INTO matches (match_id, last_runs, last_wickets, last_over, innings) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$matchId, $currentScore['runs'], $currentScore['wickets'], $currentScore['overs'], $currentScore['innings']]);
            return;
        }

        // 1. Detect Wicket
        if ($currentScore['wickets'] > $lastState['last_wickets']) {
            $this->logAndNotify($matchId, 'WICKET', "WICKET! Score: {$currentScore['runs']}/{$currentScore['wickets']}", [
                'match_id' => $matchId,
                'event_type' => 'WICKET',
                'runs' => $currentScore['runs'],
                'wickets' => $currentScore['wickets']
            ]);
        }

        // 2. Detect Milestones (50/100)
        foreach ($currentScore['batsmen'] as $batsman) {
            if ($batsman['runs'] >= 50 && $batsman['runs'] < 100) {
                $this->checkBatsmanMilestone($matchId, $batsman, 'FIFTY');
            } elseif ($batsman['runs'] >= 100) {
                $this->checkBatsmanMilestone($matchId, $batsman, 'CENTURY');
            }
        }

        // 3. Detect Innings Break
        if ($currentScore['innings'] > $lastState['innings']) {
            $this->logAndNotify($matchId, 'INNINGS_BREAK', "Innings Break: {$currentScore['runs']}/{$lastState['last_wickets']}", [
                'match_id' => $matchId,
                'event_type' => 'INNINGS_BREAK'
            ]);
        }

        // Update last state
        $stmt = $pdo->prepare("UPDATE matches SET last_runs = ?, last_wickets = ?, last_over = ?, innings = ? WHERE match_id = ?");
        $stmt->execute([$currentScore['runs'], $currentScore['wickets'], $currentScore['overs'], $currentScore['innings'], $matchId]);
    }

    private function checkBatsmanMilestone($matchId, $batsman, $type) {
        $pdo = $this->db->getConnection();
        $eventData = "batsman_{$batsman['id']}";
        
        $stmt = $pdo->prepare("SELECT id FROM events_log WHERE match_id = ? AND event_type = ? AND event_data = ?");
        $stmt->execute([$matchId, $type, $eventData]);
        
        if (!$stmt->fetch()) {
            $title = $type === 'FIFTY' ? "HALF CENTURY!" : "CENTURY!";
            $body = "{$batsman['name']} scored {$batsman['runs']} runs!";
            $this->logAndNotify($matchId, $type, $body, [
                'match_id' => $matchId,
                'event_type' => $type,
                'batsman_name' => $batsman['name']
            ], $eventData);
        }
    }

    private function logAndNotify($matchId, $type, $body, $data, $eventData = '') {
        $pdo = $this->db->getConnection();
        
        // Log event to prevent duplicates
        $stmt = $pdo->prepare("INSERT INTO events_log (match_id, event_type, event_data) VALUES (?, ?, ?)");
        $stmt->execute([$matchId, $type, $eventData]);

        // Send FCM notification
        $this->fcm->sendToTopic("match_$matchId", "Cricket Live Update", $body, $data);
    }
}
