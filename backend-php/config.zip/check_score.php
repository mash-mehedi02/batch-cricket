<?php
// backend-php/check_score.php

require_once __DIR__ . '/core/Config.php';
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/services/FcmService.php';
require_once __DIR__ . '/services/ScoreService.php';

// 1. Load Environment Variables
Config::loadEnv(__DIR__ . '/.env');

// 2. Initialize Core Services
$db = Database::getInstance();
$fcm = new FcmService();
$scoreService = new ScoreService($db, $fcm);

// 3. Define Matches to monitor (In production, load active match IDs from DB)
$activeMatches = ['match_001']; 

// 4. Poll and Process each active match
foreach ($activeMatches as $matchId) {
    try {
        $currentScore = $scoreService->fetchScore($matchId);
        $scoreService->processMatchUpdate($currentScore);
        echo "Successfully processed match: $matchId\n";
    } catch (Exception $e) {
        error_log("Error processing match $matchId: " . $e->getMessage());
        echo "Error: " . $e->getMessage() . "\n";
    }
}
